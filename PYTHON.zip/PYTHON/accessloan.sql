-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2025 at 08:39 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `accessloan`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerNo` varchar(55) NOT NULL,
  `fulname` varchar(55) NOT NULL,
  `marital` varchar(55) NOT NULL,
  `country` varchar(55) NOT NULL,
  `lgea` varchar(55) NOT NULL,
  `phone` int(55) NOT NULL,
  `account_name` varchar(55) NOT NULL,
  `loan_amount` int(55) NOT NULL,
  `month` int(55) NOT NULL,
  `basic` int(55) NOT NULL,
  `gender` varchar(55) NOT NULL,
  `dob` int(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `address` varchar(55) NOT NULL,
  `nextOfKin` varchar(55) NOT NULL,
  `acctNo` int(55) NOT NULL,
  `interest` int(55) NOT NULL,
  `type` varchar(55) NOT NULL,
  `length` int(55) NOT NULL,
  `total` varchar(55) NOT NULL,
  `interest_paid` varchar(55) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerNo`, `fulname`, `marital`, `country`, `lgea`, `phone`, `account_name`, `loan_amount`, `month`, `basic`, `gender`, `dob`, `state`, `address`, `nextOfKin`, `acctNo`, `interest`, `type`, `length`, `total`, `interest_paid`) VALUES
('2323', 'shehu haruna', 'Married', 'niger', 'birnin kebbi', 878727278, 'nana', 20000, 1, 10000, 'Female', 1022000, '', 'wala', 'jana', 8288278, 2, 'Monthly', 2, '17850', '637'),
('828291', 'AAA', 'Divorced', 'QQQ', 'JJK', 908898900, 'JJKKH', 10000, 8, 8000, 'Female', 1012000, 'Maiduguri', 'KKK', 'KJLJK', 890089899, 9, 'Weekly', 8, '8925', '318'),
('290900', 'SHEHU ALIYU', 'Single', 'NIGER', 'RANO', 908282782, 'ISHA NAMA', 10000, 2, 100020, 'Male', 1012003, 'Maiduguri', 'BAIDAWA', 'KAMAL HANA', 82899202, 1, 'Monthly', 3, '8925', '318');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffNo` varchar(55) NOT NULL,
  `fulname` varchar(55) NOT NULL,
  `marital` varchar(55) NOT NULL,
  `country` varchar(55) NOT NULL,
  `lgea` varchar(55) NOT NULL,
  `phone` int(55) NOT NULL,
  `account_name` varchar(55) NOT NULL,
  `loan_amount` int(55) NOT NULL,
  `month` int(55) NOT NULL,
  `basic` int(55) NOT NULL,
  `gender` varchar(55) NOT NULL,
  `dob` int(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `address` varchar(55) NOT NULL,
  `nextOfKin` varchar(55) NOT NULL,
  `acctNo` int(55) NOT NULL,
  `interest` int(55) NOT NULL,
  `type` varchar(55) NOT NULL,
  `length` int(55) NOT NULL,
  `total` varchar(55) NOT NULL,
  `interest_paid` varchar(55) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffNo`, `fulname`, `marital`, `country`, `lgea`, `phone`, `account_name`, `loan_amount`, `month`, `basic`, `gender`, `dob`, `state`, `address`, `nextOfKin`, `acctNo`, `interest`, `type`, `length`, `total`, `interest_paid`) VALUES
('102001', 'KHADIJA MUHAMMED', 'Married', 'MALI', 'NAMAK', 902820290, 'KAMILA MALI', 20000, 3, 2000000, 'Female', 1022005, 'Maiduguri', 'WALA', 'KAMALA KAM', 929202902, 2, 'Monthly', 2, '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
