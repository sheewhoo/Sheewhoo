# Write your code here :-)
import mysql.connector
from mysql.connector import Error
from tkinter import *
from tkinter.font import Font
from tkinter.simpledialog import askinteger
from tkinter import messagebox
import tkinter as tk
window = Tk()

window.geometry("400x600+20+30")
window.title("Simple Form")
window.configure(bg="lightgrey")


font1 = Font(family="arial",size=18, weight="bold")
labe = Label(window, text="Simple Form", font=font1, bg="lightgrey")
labe.pack()

font2 = Font(family="arial",size=16, weight="bold")
frame = Frame(window, width=250, height=400)
frame.place(x=30, y=70)
label = Label(frame, text="Username :", font=font2, bg="lightgrey")
label.grid(row=0, column=0, padx=10, pady=10)
labeltxt = Entry(frame, width=30)
labeltxt.grid(row =0, column=1, padx=10, pady=10)

labell = Label(frame, text="Email :", font=font2, bg="lightgrey")
labell.grid(row=1, column=0, padx=10, pady=10)
labelltxt = Entry(frame, width=30)
labelltxt.grid(row =1, column=1, padx=10, pady=10)

labelll = Label(frame, text="Password :", font=font2, bg="lightgrey")
labelll.grid(row=2, column=0, padx=10, pady=10)
labellltxt = Entry(frame, show="*",width=30)
labellltxt.grid(row =2, column=1, padx=10, pady=10)
def sav():
    try:
        connection = mysql.connector.connect(
        host = "localhost",
        database= "mydatabae",
        user = "root",
        password= "")
        my_cursor = connection.cursor()
        my_cursor.execute("INSERT INTO form VALUES(%s,%s,%s)",(
        labeltxt.get(),
        labelltxt.get(),
        labellltxt.get(),
        ))
        connection.commit()
        messagebox.showinfo("Hello","Data inserted successfully")
        connection.close()
    except mysql.connector.Error as e:
        messagebox.showinfo("Hello","Data  notsuccessfully")

def reset():
    labeltxt.delete(0,END)
    labelltxt.delete(0,END)
    labellltxt.delete(0,END)

btn = Button(frame, text="Submit", width=10, font=font2,command=sav)
btn.grid(row=3, column=0, padx=10,pady=10)

btn1 = Button(frame, text="Reset", command=reset, width=10, font=font2)
btn1.grid(row=3, column=1, padx=10,pady=10)

window.mainloop()
