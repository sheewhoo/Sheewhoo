# Write your code here :-)
from tkinter import *
import mysql.connector
from mysql.connector import Error
from tkinter.font import Font
from tkinter.simpledialog import askstring
from tkinter import messagebox
window=Tk()
window.geometry("400x700+2+2")
window.title("Registatrion Form")
window.configure(bg="lightgrey")

def sav():
    try:
        connection = mysql.connector.connect(
        host = "localhost",
        database= "mydatabae",
        user = "root",
        password= "")
        my_cursor = connection.cursor()
        my_cursor.execute("INSERT INTO student VALUES(%s,%s,%s,%s)",(
        nametxt.get(),
        gendetxt.gender(),
        phonetxt.get(),
        addresstxt.get(),
        ))
        connection.commit()
        messagebox.showinfo("Hello","Data inserted successfully")
        connection.close()
    except mysql.connector.Error as e:
        messagebox.showinfo("Hello","Data inserted successfully")

font1 = Font(family="arial", size=18, weight="bold")
lab1 = Label(window, text="Registatrion Form", font=font1)
lab1.pack()
font2 = Font(family="arial", size=14, weight="bold")
frame = Frame(window, width=300, height=500)
frame.place(x=10, y=40)
name = Label(frame, text="Name",font=font2)
name.grid(row=0, column=0)
nametxt=Entry(frame, width=20)
nametxt.grid(row=0, column=1)

gende = Label(frame, text="Gender",font=font2)
gende.grid(row=1, column=0)
gendetxt=Entry(frame, width=20)
gendetxt.grid(row=1, column=1)

phone = Label(frame, text="Phone Number",font=font2)
phone.grid(row=2, column=0)
phonetxt=Entry(frame, width=20)
phonetxt.grid(row=2, column=1)

address = Label(frame, text="address",font=font2)
address.grid(row=3, column=0)
addresstxt=Entry(frame, width=20)
addresstxt.grid(row=3, column=1)




btn1 = Button(frame, text= "submit", width=15, command=sav)
btn1.grid(row=4, columnspan=2)
window.mainloop
# Write your code here :-)
