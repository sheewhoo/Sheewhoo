from tkinter.simpledialog import askstring
from tkinter.simpledialog import askinteger
from tkinter.simpledialog import askfloat
from tkinter import messagebox
import tkinter as tk
root = tk. Tk()
root.withdraw
root.resizable(True,True)
from tkinter import*
root.title("Records")
root.geometry("400x300")
labe1 = Label(root, text="Value A", width=20).grid(row=0,column=0, padx=2,pady=4)
label1_txt = Entry(root,width=20).grid(row=0,column=1, padx=2,pady=4)
labe2 = Label(root, text="Value B.", width=20).grid(row=0,column=2, padx=2,pady=4)
label2_txt = Entry(root,width=20).grid(row=0,column=3, padx=2,pady=4)
labe3 = Label(root, text="Value C", width=20).grid(row=1,column=0, padx=2,pady=4)
label3_txt = Entry(root,width=20).grid(row=1,column=1, padx=2,pady=4)
labe4 = Label(root, text="Value D.", width=20).grid(row=1,column=2, padx=2,pady=4)
label4_txt = Entry(root,width=20).grid(row=1,column=3, padx=2,pady=4)


def sal():
    lab1 =label1_txt.get()
    lab2 =label2_txt.get()
    lab3 =label3_txt.get()
    a=int(lab1)
    b=int(lab2)
    c=int(lab3)
    balance = a+b+c
    avg =balance/3

    label4_txt.insert(0,str(avg))


btn = Button(root, text="Total", width=20, command=sal).grid(row=2, column=2, padx=2,pady=2)
root.mainloop()
