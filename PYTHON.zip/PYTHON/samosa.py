# Write your code here :-)
from tkinter import *
window = Tk()
window.geometry("700x400")
window.resizable(width="false",height="false")
window.title("Hanna Resturant")

header = Label(window,text="HANNA RESTURANT FUBK",font="times,20")
header.pack()

samosa = Label(window,text="Samosa     N200",font="times,14")
samosa.place(x=500, y=40)
fried_rice = Label(window,text="Fried Rice     N1500",font="times,14")
fried_rice.place(x=500, y=60)

egg_roll = Label(window,text="Egg Roll     N300",font="times,14")
egg_roll.place(x=500, y=80)


shawarma = Label(window,text="Shawarma     N3000",font="times,14")
shawarma.place(x=500, y=100)
selectItem = Label(window,text="Pay On Item Selected", font="times, 16")
selectItem.place(x=30, y=60)

salabel = Label(window,text="Samosa ",font="times,14")
salabel.place(x=30, y=100)
salabel = Entry(window, )
salabel.place(x=30, y=120)

flabel = Label(window,text="Fried Rice ",font="times,14")
flabel.place(x=200, y=100)
flabel = Entry(window, )
flabel.place(x=200, y=120)

elabel = Label(window,text="Egg Roll ",font="times,14")
elabel.place(x=30, y=160)
elabel = Entry(window, )
elabel.place(x=30, y=180)
shlabel = Label(window,text="Shawarma ",font="times,14")
shlabel.place(x=200, y=160)
shlabel = Entry(window, )
shlabel.place(x=200, y=180)

def cal():
    num1 = salabel.get()
    num2 = flabel.get()
    num3 = elabel.get()
    num4 = shlabel.get()
    samosa = int(num1)*200
    fried = int(num2)*1500
    egg = int(num3)*300
    shawarma= int(num4)*3000
    total = (samosa+fried+egg+shawarma)
    tlabel = Label(window,text=total, font="arial, 20")
    tlabel.place(x=300, y=300)
    ttlabel = Label(window,text="Amount to be Pay N", font="arial, 20")
    ttlabel.place(x=50, y=300)

def reset():
    salabel.delete(0,END)
    flabel.delete(0,END)
    elabel.delete(0,END)
    shlabel.delete(0,END)

btn = Button(window, text="Calculate", command=cal,font="times, 14")
btn.place(x=150,y=230)
btn1 = Button(window, text="Reset", command=reset,font="times, 14")
btn1.place(x=350, y=230)


window.mainloop()
