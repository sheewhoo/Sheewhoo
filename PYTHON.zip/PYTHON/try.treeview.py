# Write your code here :-)
import mysql.connector
from mysql.connector import Error
from tkinter import *
from tkinter import ttk
import tkinter as tk





root = Tk()
root.geometry("1200x600+30+40")
root.resizable(width="false",height="false")
root.configure(bg="grey")
root.title("Search")
connection = mysql.connector.connect(host = "localhost",database= "accessloan",user = "root",password= "")
c = connection.cursor()
def button_back():
    root.destroy ()
    import panel
frame = ttk.Frame(root, )
scrollbarx =Scrollbar(frame, orient=HORIZONTAL)
scrollbarx.place(relx=0.002, rely=0.922, width=1200,height=22)
scrollbary =Scrollbar(frame, orient=VERTICAL)
scrollbary.place(relx=0.98, rely=0.128, width=22,height=400)


Label_search = Label(frame, text="Search by Customer No", font=("arial, 12"))
entry_search = Entry(frame,  font=("arial, 12"))
button_search = Button(frame, text="Search ", font=("arial, 12"), width=20)
button_back = Button(frame, text="Back ", font=("arial, 12"), width=20, command=button_back)

lmm = ttk.Treeview(frame, columns=(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21), height=15, show="headings")
lmm.place(relx=0.01, rely=0.128, width=1150,height=450)
lmm.column(1, anchor=CENTER, stretch=NO, width=100)
lmm.column(2, anchor=CENTER, stretch=NO, width=100)
lmm.column(3, anchor=CENTER, stretch=NO, width=100)
lmm.column(4, anchor=CENTER, stretch=NO, width=100)
lmm.column(5, anchor=CENTER, stretch=NO, width=100)
lmm.column(6, anchor=CENTER, stretch=NO, width=100)
lmm.column(7, anchor=CENTER, stretch=NO, width=100)
lmm.column(8, anchor=CENTER, stretch=NO, width=100)
lmm.column(9, anchor=CENTER, stretch=NO, width=100)
lmm.column(10, anchor=CENTER, stretch=NO, width=100)
lmm.column(11, anchor=CENTER, stretch=NO, width=100)
lmm.column(12, anchor=CENTER, stretch=NO, width=100)
lmm.column(13, anchor=CENTER, stretch=NO, width=100)
lmm.column(14, anchor=CENTER, stretch=NO, width=100)
lmm.column(15, anchor=CENTER, stretch=NO, width=100)
lmm.column(16, anchor=CENTER, stretch=NO, width=100)
lmm.column(17, anchor=CENTER, stretch=NO, width=100)
lmm.column(18, anchor=CENTER, stretch=NO, width=100)
lmm.column(19, anchor=CENTER, stretch=NO, width=100)
lmm.column(20, anchor=CENTER, stretch=NO, width=100)
lmm.column(21, anchor=CENTER, stretch=NO, width=100)


lmm.heading(1, text="Customer No")
lmm.heading(2, text="Full Name")
lmm.heading(3, text=" Status")
lmm.heading(4, text="Country")
lmm.heading(5, text="LGA")
lmm.heading(6, text="Phone")
lmm.heading(7, text="Acct Name")
lmm.heading(8, text="Loan Amount")
lmm.heading(9, text="Monthly Payment")
lmm.heading(10, text="Salary")
lmm.heading(11, text="Gender")
lmm.heading(12, text="DoB")
lmm.heading(13, text="State")
lmm.heading(14, text="Address")
lmm.heading(15, text="NextOfKin")
lmm.heading(16, text="Acct No")
lmm.heading(17, text="Interst")
lmm.heading(18, text="Type")
lmm.heading(19, text="Lenght")
lmm.heading(20, text="Total")
lmm.heading(21, text="Interest_Paid")

def find():

    val = entry_search.get()
    c.execute("SELECT * FROM `customer` WHERE `customerNo` LIKE %s or `fullname` like %s",("%s"+val+"%s","%s"+val+"%s"))
    customer = my_cursor.fetchall()

    for row in customer:
        lmm.insert("",END,values=row)

button_search['command'] = find


Label_search.place(x=10, y=20)
entry_search.place(x=200, y=20)
button_search.place(x=400, y=15)
button_back.place(x=600, y=15)

lmm.place(x=10, y=25)
frame.place(x=1, y=10, width=1200,height=600)



root.mainloop()
