# Write your code here :-)
# Write your code here :-)
# Write your code here :-)
import math
from tkinter import ttk
from tkinter import*
from tkinter import messagebox
window = Tk()
window.geometry("800x500")
window.title("School Management System")
window.configure(bg="white")
def exit():
    window.destroy()

lab = Label(window,text="POLYTECHNIC STAFF ACADEMY", font="arial, 18", bg="white")
lab.pack()
lab = Label(window,text="SCHOOL MANAGEMENT SYSTEM", font="arial, 18", bg="white")
lab.pack()

leftframe = Frame(window, width="300",height="300",bg="grey")
leftframe.place(x=30,y=80)


addbtn = Button(leftframe, text="ADD STUDENT", width="30", bg="white")
addbtn.grid(row=1, column=1,padx=2, pady=2)

delbtn = Button(leftframe, text=" UPDATE STUDENT", width="30", bg="white")
delbtn.grid(row=2, column=1,padx=2, pady=2)

delbtn = Button(leftframe, text=" VIEW RECORDS ", width="30", bg="white")
delbtn.grid(row=3, column=1,padx=2, pady=2)
updatebtn = Button(leftframe, text=" DELETE STUDENT", width="30", bg="white")
updatebtn.grid(row=4, column=1,padx=2, pady=2)
exitbtn = Button(leftframe, text=" Exit", command=exit, width="30", bg="white")
exitbtn.grid(row=5, column=1,padx=2, pady=2)


rightframe=Frame(window,bg="WHITE",width=300, height=500)
rightframe.place(x=300,y=70)

scrollbarx=Scrollbar(rightframe, orient=HORIZONTAL)
scrollbary=Scrollbar(rightframe, orient=VERTICAL)
studenttable=ttk.Treeview(rightframe, columns=("id","name","sex","marital status"))
studenttable.pack(fill=BOTH)
scrollbarx.pack(side=BOTTOM, fill="x")
scrollbary.pack(side=RIGHT, fill="y")

window.mainloop()

