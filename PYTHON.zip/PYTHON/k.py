

import math
from tkinter import*
from tkinter import messagebox
root = Tk()
root.title("3 Values Calculator")
root.geometry("700x400")

lab_a = Label(root, text="Value A").grid(row=0,column=0, padx=2,pady=4)
atxt=Entry(root, width=20).grid(row=0,column=1, padx=2,pady=4)
lab_b = Label(root, text="Value b").grid(row=0,column=2, padx=2,pady=4)
btxt=Entry(root, width=20).grid(row=0,column=3, padx=2,pady=4)
lab_c = Label(root, text="Value C").grid(row=1,column=0, padx=2,pady=4)
ctxt=Entry(root, width=20).grid(row=1,column=1, padx=2,pady=4)
lab_total =Label(root, text="Total").grid(row=1,column=2, padx=2,pady=4)
ttl =Entry(root, width=20).grid(row=1,column=3, padx=2,pady=4)


def sav():
        num1 = atxt.get()
        num2 = btxt.get()
        num3 = ctxt.get()

        sums = int(num1)+int(num2)+int(num3)
        ttl.insert(0,str(sums))


btn =Button(root, text="Total", width=20, command=sav).grid(row=2,column=3)
root.mainloop()
