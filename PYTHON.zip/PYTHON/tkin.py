# Write your code here :-)
from tkinter import*
from tkinter.simpledialog import askstring
from tkinter.simpledialog import askfloat
from tkinter.simpledialog import askinteger
from tkinter import messagebox
import tkinter as tk
import math
root= Tk()

name = askstring("input","Enter Your Fullname")
deprt = askstring("input","Enter Your Department")
course = askstring("input","Enter Course")
test = askfloat("input","Enter Test Score")
exam = askfloat("input","Enter Exam Score")

total = test+exam
main_total = (0,str(total))

if total >= 75 and total<=100:

    messagebox.showinfo("Score Sheet", "Hello "+name+" of the department of "+course+"you have grade"+deprt+" congratulations")
else:
    messagebox.showinfo("Score Sheet", "Hello  congratulations")

root.mainloop()
