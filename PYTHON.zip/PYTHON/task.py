# Write your code here :-)
import mysql.connector
from mysql.connector import Error
from tkinter import *
from tkinter import ttk
from tkinter.simpledialog import askstring
import tkinter as tk

window = Tk()
window.geometry("400x400")
window.configure(bg="lightpink")


lmm = ttk.Treeview(window, columns=(1,2,3,4,5,6), height=15, show="headings")
lmm.pack()
lmm.column(1, anchor=CENTER, stretch=NO, width=100)
lmm.column(2, anchor=CENTER, stretch=NO, width=100)
lmm.column(3, anchor=CENTER, stretch=NO, width=100)
lmm.column(4, anchor=CENTER, stretch=NO, width=100)
lmm.column(5, anchor=CENTER, stretch=NO, width=100)
lmm.column(6, anchor=CENTER, stretch=NO, width=100)

lmm.heading(1, text="Customer No")
lmm.heading(2, text="Full Name")
lmm.heading(3, text="Gender")
lmm.heading(4, text="State")
lmm.heading(5, text="LOAN AMOUNT")
lmm.heading(6, text="INTEREST")


window.mainloop()
