# Write your code here :-)

from tkinter import*
import time
def clock():
    date=time.strftime('%d/%m/%Y')
    currenttime=time.strftime('%H:%M:%S')
    datetimeLabel.config(text=f'     Date:{date}\nTime: {currenttime}')
    datetimeLabel.after(1000,clock)


root = Tk()
root.maxsize(660,330)
root.title('time')
datetimeLabel=Label(root, font=('arial', 18, 'bold'))
datetimeLabel.pack()
clock()

root.mainloop()
