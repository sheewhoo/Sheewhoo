# Write your code here :-)
import time
def clock():
    date=time.strftime('%d/%m/%Y')
    currenttime=time.strftime('%H:%M:%S')
    datetimeLabel.config(text=f' Date:{date}\nTime: {currenttime}')
    datetimeLabel.after(1000,clock)



import mysql.connector
from mysql.connector import Error
from tkinter.simpledialog import askstring
from tkinter import messagebox
import tkinter as tk
import math
from tkinter import *
from tkinter.font import Font
from tkinter import ttk
window=Tk()
window.title("ACCESS BANK LOAN PANEL")
window.geometry("700x400")
window.resizable(width="false", height="false")
font = Font(family="arial", size="17", weight="bold")
font1 = Font(family="arial", size="16", weight="bold")

label = Label(window, text="ACCESS BANK PLC,", font=font)
label1 = Label(window, text="CUSTOMER PANEL", fg="lightgrey",font=font1)
label.pack()
label1.pack()

leftframe = Frame(window, width=200, height=300, bg="lightgrey")
leftframe.place(x=30, y=80)

font2 = Font(family="arial", size="10", weight="bold")

rightframe = Frame(window, width=300, height=300)
rightframe.place(x=300, y=80)




datetimeLabel=Label(rightframe, font=('arial', 18, 'bold'))
datetimeLabel.pack()
clock()




customerbtn = Button(leftframe, text="Customer",  bg="grey", width=15, height=2, font=font2)
customerbtn.grid(row=0,column=0)

staffbtn = Button(leftframe, text="Staff",  bg="grey", width=15, height=2,font=font2)
staffbtn.grid(row=1,column=0)

creditslipbtn = Button(leftframe, text="Credit Slip", bg="grey", width=15, height=2, font=font2)
creditslipbtn.grid(row=2,column=0)

loanslipbtn = Button(leftframe, text="Credited Loan",  bg="grey", width=15, height=2,font=font2)
loanslipbtn.grid(row=3,column=0)

aboutbtn = Button(leftframe, text="About System", bg="grey", width=15, height=2, font=font2)
aboutbtn.grid(row=4,column=0)

logoutbtn = Button(leftframe, text="Logout", command=logout, bg="grey", width=15, height=2,font=font2)
logoutbtn.grid(row=5,column=0)
closebtn = Button(leftframe, text="Close", command=close, bg="grey", width=15, height=2,font=font2)
closebtn.grid(row=6,column=0)

window.mainloop()
