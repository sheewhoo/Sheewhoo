# Write your code here :-)
import tkinter as tk
import mysql.connector
from mysql.connector import Error
from tkinter.simpledialog import askstring
from tkinter import messagebox
from tkinter import *
window = Tk()
window.geometry("400x300")
window.configure(bg="lightgrey")
name = Label(window,text="Name :-", bg="lightgrey", font="arial, 17")
name.grid(row=0, column=0, padx=10,pady=10)
nametxt = Entry(window, width=25)
nametxt.grid(row=0, column=1)

address = Label(window,text="Address :-", bg="lightgrey", font="arial, 17")
address.grid(row=1, column=0, padx=10,pady=10)
addresstxt = Entry(window,width=20,)
addresstxt.grid(row=1, column=1)

def save():
    try:
        connection = mysql.connector.connect(
        host ="localhost",
        database="accessloan",
        user = "root",
        password="")
        my_cursor = connection.cursor()
        my_cursor.execute("INSERT INTO home VALUES(%s,%s)",(
        nametxt.get(),
        addresstxt.get(),
        ))
        connection.commit()
        messagebox.showinfo("Info","Data inserted Successfully")
        connection.close()
    except mysql.connector.Error as e:
        messagebox.showinfo("Error", "Data not inserted")

btn = Button(window,text="Submit", command=save,width=20)
btn.grid(row=2, columnspan=3, padx=10, pady=10)
window.mainloop()
