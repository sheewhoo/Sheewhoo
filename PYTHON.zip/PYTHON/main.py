# Write your code here :-)
import math

from tkinter import*
from tkinter import messagebox
root = Tk()
root.maxsize(660,330)
root.minsize(100,200)

root.title("sum of two numbers")

flabel = Label(root, text="Num 1").grid(row=0,column=0, padx=2,pady=2)
ftxt = Entry(root, width=20)
ftxt.grid(row=0, column=1, padx=2, pady=2)

slabel = Label(root, text="Num 2").grid(row=0,column=3, padx=2,pady=2)
stxt = Entry(root, width=20)
stxt.grid(row=0, column=4, padx=2, pady=2)

tlabel = Label(root, text="Total").grid(row=0,column=5, padx=2,pady=2)
ttxt = Entry(root, width=20)
ttxt.grid(row=0, column=6, padx=2, pady=2)


def sav():
    num1 = ftxt.get()
    num2 = stxt.get()

    sums = float(num1)+float(num2)
    ttxt.insert(0,str(sums))

btn = Button(root, text="Total", width=20, command=sav)
btn.grid(row=1, column=1)
root.mainloop()
