# Write your code here :-)
# Write your code here :-)
import math

from tkinter import*
from tkinter import messagebox
root = Tk()
root.maxsize(660,330)
root.minsize(300,200)
root.title("sum of two numbers")


varr = IntVar()
c = Checkbutton(root, text="Fuck You", variable=varr).pack()
lab = Label(root, text=varr.get()).pack()




root.mainloop()
