# Write your code here :-)
import math
from tkinter.font import Font
from mysql.connector import Error

from tkinter import *
from tkinter import messagebox
from tkinter import ttk
window = Tk()
window.title("MEDICAL RECORDS SYSTEM")
window.geometry("800x500+200+100")

varr = IntVar()
c = Checkbutton(window,text="Hit me pls", variable=varr)
mylabel=Label(window, text=varr.get())
c.pack()

mylabela = ttk.Treeview(window, columns=("id","name","school")).pack()

window.mainloop()
