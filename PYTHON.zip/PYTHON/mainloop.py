import mysql.connector
from mysql.connector import Error
from tkinter import *
import tkinter as tk
from tkinter.simpledialog import askstring
from tkinter import messagebox
from tkinter.font import Font


window = Tk()
window.geometry("400x400")
window.resizable(width="false",height="false")
window.configure(bg="lightblue")
window.title("Records Management")
font = Font(family="arial", size=18, weight="bold")
header = Label(window, text="Main Records", bg="lightblue", font=font)
header.pack()
fram =Frame(window, width=460, height=300, bg="white", border=2)
fram.place(x=20, y=35)

font1 = Font(family="arial", size=16, weight="bold")
custno = Label(fram, text="Customer No:", font = font1, bg="white")
custno.grid(row= 0, column=0, padx=10,pady=10)
custnotxt = Entry(fram,width=30, border=2)
custnotxt.grid(row=0, column=1, padx=10,pady=10)

name = Label(fram, text="Name: ", font = font1, bg="white")
name.grid(row= 1, column=0, padx=10,pady=10)
nametxt = Entry(fram,width=30, border=2)
nametxt.grid(row=1, column=1, padx=10,pady=10)


phone = Label(fram, text="Phone No: ", font = font1, bg="white")
phone.grid(row= 2, column=0, padx=10,pady=10)
phonetxt = Entry(fram,width=30, border=2)
phonetxt.grid(row=2, column=1, padx=10,pady=10)

address = Label(fram, text="Address: ", font = font1, bg="white")
address.grid(row= 3, column=0, padx=10,pady=10)
addresstxt = Entry(fram,width=30, border=2)
addresstxt.grid(row=3, column=1, padx=10,pady=10)

dob = Label(fram, text="Date of Birth: ", font = font1, bg="white")
dob.grid(row= 4, column=0, padx=10,pady=10)
dobtxt = Entry(fram,width=30, border=2)
dobtxt.grid(row=4, column=1, padx=10,pady=10)
def save():
    try:
        connection = mysql.connector.connect(
        host="localhost",
        database="mydatabae",
        user = "root",
        password = "")
        my_cursor = connection.cursor()
        my_cursor.execute("INSERT INTO customer VALUES(%s,%s,%s,%s,%s)",(
        custnotxt.get(),
        nametxt.get(),
        phonetxt.get(),
        addresstxt.get(),
        dobtxt.get(),
        ))
        connection.commit()
        messagebox.showinfo("Congratulations","Records Inserted Successfully")
        connection.close()
    except mysql.connector.Error as e:
        messagebox.showerror("Error", "Records not inserted")
btn = Button(fram, text="Submit", command=save, font=font1)
btn.grid(row=5, columnspan=2, padx=10, pady=10)
window.mainloop()
