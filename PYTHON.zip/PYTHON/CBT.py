import tkinter as tk
import random

# Sample questions for each subject (Math, English, Chemistry, Physics)
questions = {
    "Math": [
        {"question": "What is 2 + 2?", "options": [4, 3, 6, 5], "answer": 4},
        {"question": "What is 12 * 12?", "options": [144, 134, 121, 155], "answer": 144},
        {"question": "What is 3 + 5?", "options": [6, 7, 8, 9], "answer": 8},
        {"question": "What is 15 - 7?", "options": [8, 7, 6, 5], "answer": 8},
        {"question": "What is 9 * 9?", "options": [81, 90, 72, 64], "answer": 81},
        {"question": "What is 18 / 2?", "options": [9, 7, 8, 10], "answer": 9},
        {"question": "What is 3^3?", "options": [27, 24, 30, 32], "answer": 27},
        {"question": "What is the square root of 49?", "options": [7, 5, 8, 6], "answer": 7},
        {"question": "What is 14 + 9?", "options": [22, 23, 21, 20], "answer": 23},
        {"question": "What is 25 - 4?", "options": [21, 23, 22, 20], "answer": 21},
        {"question": "What is 10 * 3?", "options": [30, 32, 28, 35], "answer": 30},
        {"question": "What is 7 * 6?", "options": [42, 36, 48, 49], "answer": 42},
        {"question": "What is 100 / 5?", "options": [20, 15, 25, 30], "answer": 20},
        {"question": "What is 2 + 6 * 3?", "options": [20, 18, 22, 19], "answer": 20},
        {"question": "What is 8 - 3?", "options": [4, 5, 6, 3], "answer": 5},
        {"question": "What is 7 + 3 * 2?", "options": [13, 14, 15, 16], "answer": 13},
        {"question": "What is 9 + 2 * 5?", "options": [19, 20, 21, 18], "answer": 19},
        {"question": "What is 6 * 8?", "options": [48, 50, 55, 42], "answer": 48},
        {"question": "What is 50 / 10?", "options": [5, 10, 8, 6], "answer": 5},
        {"question": "What is 16 + 9?", "options": [24, 25, 27, 26], "answer": 25},
        {"question": "What is 30 / 3?", "options": [10, 8, 12, 9], "answer": 10},
        {"question": "What is 7 * 5?", "options": [35, 36, 37, 34], "answer": 35},
        {"question": "What is 3 + 4 * 2?", "options": [11, 13, 10, 12], "answer": 11},
        {"question": "What is 6 + 5?", "options": [10, 11, 12, 9], "answer": 11},
        {"question": "What is 8 * 8?", "options": [64, 60, 66, 68], "answer": 64},
        {"question": "What is 5 + 7?", "options": [12, 14, 11, 13], "answer": 12},
        {"question": "What is 18 / 3?", "options": [5, 6, 7, 4], "answer": 6}
    ],
    # Add English, Chemistry, and Physics questions similarly
}

# Function to shuffle and generate questions
def generate_questions(subject, num_questions=25):
    subject_questions = questions.get(subject, [])
    return random.sample(subject_questions, num_questions)

# GUI for generating and displaying the questions
class CBTApp:
    def __init__(self, root):
        self.root = root
        self.root.title("CBT Exam Generator")
        self.root.geometry("600x500")

        self.subjects = ["Math", "English", "Chemistry", "Physics"]

        self.subject_label = tk.Label(root, text="Select Subject", font=("Arial", 16))
        self.subject_label.pack(pady=10)

        self.subject_var = tk.StringVar()
        self.subject_menu = tk.OptionMenu(root, self.subject_var, *self.subjects)
        self.subject_menu.pack(pady=20)

        self.generate_button = tk.Button(root, text="Generate Exam", command=self.generate_exam, font=("Arial", 14))
        self.generate_button.pack(pady=20)

        self.questions_frame = tk.Frame(root)
        self.questions_frame.pack(fill=tk.BOTH, expand=True)

    def generate_exam(self):
        subject = self.subject_var.get()
        if subject:
            questions_list = generate_questions(subject)
            self.display_questions(questions_list)
        else:
            self.clear_questions()

    def display_questions(self, questions_list):
        # Clear previous questions if any
        self.clear_questions()

        for idx, question in enumerate(questions_list, start=1):
            q_label = tk.Label(self.questions_frame, text=f"{idx}. {question['question']}", font=("Arial", 12))
            q_label.pack(anchor="w", padx=20, pady=5)

            # Create checkboxes for options A, B, C, D
            var_a = tk.IntVar()
            var_b = tk.IntVar()
            var_c = tk.IntVar()
            var_d = tk.IntVar()

            options = question["options"]

            checkbox_a = tk.Checkbutton(self.questions_frame, text=f"A. {options[0]}", variable=var_a)
            checkbox_b = tk.Checkbutton(self.questions_frame, text=f"B. {options[1]}", variable=var_b)
            checkbox_c = tk.Checkbutton(self.questions_frame, text=f"C. {options[2]}", variable=var_c)
            checkbox_d = tk.Checkbutton(self.questions_frame, text=f"D. {options[3]}", variable=var_d)

            checkbox_a.pack(anchor="w", padx=40, pady=2)
            checkbox_b.pack(anchor="w", padx=40, pady=2)
            checkbox_c.pack(anchor="w", padx=40, pady=2)
            checkbox_d.pack(anchor="w", padx=40, pady=2)

            # Store the checkboxes for future reference (e.g., for answers)
            question["vars"] = [var_a, var_b, var_c, var_d]

    def clear_questions(self):
        for widget in self.questions_frame.winfo_children():
            widget.destroy()

# Run the app
if __name__ == "__main__":
    root = tk.Tk()
    app = CBTApp(root)
    root.mainloop()
