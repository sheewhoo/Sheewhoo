# Write your code here :-)
# Write your code here :-)
import math

from tkinter import*
from tkinter import messagebox
root = Tk()
root.maxsize(660,330)
root.minsize(300,200)
root.title("sum of two numbers")




var = StringVar()
c = Checkbutton(root, text= "I dare you to clicks  this box", variable=var)
mylabel = Label(root, text=var.get())

c.pack()

btn = Button(root,text="Clicks").pack()
root.mainloop()
