# Write your code here :-)
import mysql.connector
from mysql.connector import Error
from tkinter.simpledialog import askstring
from tkinter import messagebox
import tkinter as tk
from tkinter import *
from tkinter.font import Font
from tkinter import ttk
window=Tk()
window.title("ACCESS BANK LOAN PANEL")
window.resizable(width="false", height="false")
window.geometry("350x450+680+10")
font = Font(family="arial", size="17", weight="bold")
font1 = Font(family="arial", size="16", weight="bold")
frame = Frame(window,)
frame.pack()



font2 = Font(family="arial", size="10", weight="bold")

def back():
    window.destroy()
    import panel



def delete():
    try:
        connection = mysql.connector.connect(
        host = "localhost",
        database= "accessloan",
        user = "root",
        password= "")
        my_cursor = connection.cursor()
        my_cursor.execute("DELETE FROM staff where staffNo=" +custnotxt.get())
        connection.commit()
        messagebox.showinfo("Hello","Data delete successfully")
        connection.close()
    except mysql.connector.Error as e:
        messagebox.showinfo("Hello"," No record found")

def reset():
    custnotxt.delete(0,END)
mainframe = Frame(window, width=300,height=300, bg="white")
mainframe.place(x=15,y=10)
la = Label(mainframe, text="DELETE RECORD: ", font="arial, 18", bg="white")
la.place(x=50, y=80)
fname = Label(mainframe, text="Staff -No:-", bg="white",font= font2 )
fname.place(x=50, y=120)
custnotxt= Entry(mainframe,width=30,border=2)
custnotxt.place(x=50, y=150)


btn1 = Button(mainframe,text="Delete", command=delete, width=9,font=font2)
btn1.place(x=50, y=220)
btn2 = Button(mainframe,text="Reset",  command=reset, width=9,font=font2)
btn2.place(x=140, y=220)

window.mainloop()
