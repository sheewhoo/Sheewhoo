# Write your code here :-)
# Write your code here :-)
# Write your code here :-)
import mysql.connector
from mysql.connector import Error
from tkinter.simpledialog import askstring
from tkinter import messagebox
import tkinter as tk
from tkinter import *
from tkinter.font import Font
from tkinter import ttk
window=Tk()

window.title("ACCESS BANK LOAN PANEL")
window.resizable(width="false", height="false")
window.geometry("1100x660+2+2")
font = Font(family="arial", size="17", weight="bold")
font1 = Font(family="arial", size="16", weight="bold")
frame = Frame(window,)
frame.pack()
label = Label(frame, text="STAFF MAIN MENU", font=font)
label.pack()
mid = Frame(window,width=1320, height=70, bg="lightgrey")
mid.place(x=10,y=40)

font2 = Font(family="arial", size="10", weight="bold")

def back():
    window.destroy()
    import panel




def sdelete():
    import sdelete





staffbtn = Button(mid, text="Edit Customer",  bg="grey", width=25, height=2,font=font2)
staffbtn.grid(row=0,column=0)

creditslipbtn = Button(mid, text="Delete Customer", command=sdelete, bg="grey", width=25, height=2, font=font2)
creditslipbtn.grid(row=0,column=1)

loanslipbtn = Button(mid, text="Reprint Approval form",  bg="grey", width=25, height=2,font=font2)
loanslipbtn.grid(row=0,column=2)

aboutbtn = Button(mid, text="list of Customer", bg="grey", width=25, height=2, font=font2)
aboutbtn.grid(row=0,column=3)

aboutbtn = Button(mid, text="Back to Panel", command=back, bg="grey", width=25, height=2, font=font2)
aboutbtn.grid(row=0,column=4)


mainframe = Frame(window, width=1320,height=530, bg="lightblue")
mainframe.place(x=130,y=110)

custno = Label(mainframe,text="Staff No:-", bg="lightblue", font=font2)
custno.grid(row=0, column=0, padx=10, pady=10)
custnotxt= Entry(mainframe,width=20,border=2)
custnotxt.grid(row=0, column=1,padx=10, pady=10)
fname = Label(mainframe, text="Ful-Name:-", bg="lightblue",font= font2 )
fname.grid(row=0, column=2, padx=10, pady=10)
fnametxt = Entry(mainframe,width=20,border=2)
fnametxt.grid(row=0, column=3,padx=10, pady=10)

ttk.Label(mainframe, text="Gender:- ", font=font2).grid(row=1, column=0, padx=10, pady=10)
n = StringVar()
gende=ttk.Combobox(mainframe,  textvariable=n)
gende["values"]=("Male","Female","Other")
gende.grid(row=1, column=1,padx=10, pady=10)
gende.current()
ttk.Label(mainframe, text="Marital Status:- ",font=font2).grid(row=1, column=2, padx=10, pady=10)
n = StringVar()
marital=ttk.Combobox(mainframe,  textvariable=n)
marital["values"]=("Single","Married","Divorced","Widow")
marital.grid(row=1, column=3,padx=10, pady=10)
marital.current()
dob = Label(mainframe, text="Date of Birth:-", bg="lightblue", font= font2 )
dob.grid(row=2, column=0, padx=10, pady=10)
dobtxt = Entry(mainframe,width=20,border=2)
dobtxt.grid(row=2, column=1, padx=10, pady=10)

country = Label(mainframe, text="Country:-", bg="lightblue", font= font2 )
country.grid(row=2, column=2, padx=10, pady=10)
countrytxt = Entry(mainframe,width=20,border=2)
countrytxt.grid(row=2, column=3, padx=10, pady=10)

ttk.Label(mainframe, text="State of Origin:- ",font=font2).grid(row=3, column=0, padx=10, pady=10)
n = StringVar()
state=ttk.Combobox(mainframe,  textvariable=n)
state["values"]=("Sokoto","Maiduguri","Delta","Kebbi")
state.grid(row=3, column=1,padx=10, pady=10)
state.current()


lgea = Label(mainframe, text="Local Govt:-", bg="lightblue", font= font2 )
lgea.grid(row=3, column=2, padx=10, pady=10)
lgeatxt = Entry(mainframe,width=20, border=2)
lgeatxt.grid(row=3, column=3, padx=10, pady=10)



addr = Label(mainframe, text="Address :-", bg="lightblue", font= font2 )
addr.grid(row=4, column=0, padx=10, pady=10)
addrtxt = Entry(mainframe,width=20, border=2)
addrtxt.grid(row=4, column=1, padx=10, pady=10)
phone = Label(mainframe, text="Phone Number:-", bg="lightblue", font= font2 )
phone.grid(row=4, column=2, padx=10, pady=10)
phonetxt = Entry(mainframe,width=20, border=2)
phonetxt.grid(row=4, column=3, padx=10, pady=10)
kin = Label(mainframe, text="Next of Kin:-", bg="lightblue", font= font2 )
kin.grid(row=5, column=0, padx=10, pady=10)
kintxt = Entry(mainframe,width=20, border=2)
kintxt.grid(row=5, column=1, padx=10, pady=10)

acct = Label(mainframe, text="Account Name:-", bg="lightblue", font= font2 )
acct.grid(row=5, column=2, padx=10, pady=10)
accttxt = Entry(mainframe,width=20, border=2)
accttxt.grid(row=5, column=3, padx=10, pady=10)

acctnum = Label(mainframe, text="Account Number:-", bg="lightblue", font= font2 )
acctnum.grid(row=6, column=0, padx=10, pady=10)
acctnumtxt = Entry(mainframe,width=20, border=2)
acctnumtxt.grid(row=6, column=1, padx=10, pady=10)

lamount = Label(mainframe, text="Loan Amount:-", bg="lightblue", font= font2 )
lamount.grid(row=6, column=2, padx=10, pady=10)
lamounttxt = Entry(mainframe,width=20, border=2)
lamounttxt.grid(row=6, column=3, padx=10, pady=10)
interest = Label(mainframe, text="Interest :-", bg="lightblue", font= font2 )
interest.grid(row=7, column=0, padx=10, pady=10)
interesttxt = Entry(mainframe,width=20, border=2)
interesttxt.grid(row=7, column=1, padx=10, pady=10)

numonth = Label(mainframe, text=" Numberof Month's :-", bg="lightblue", font= font2 )
numonth.grid(row=7, column=2, padx=10, pady=10)
numonthtxt = Entry(mainframe,width=20, border=2)
numonthtxt.grid(row=7, column=3, padx=10, pady=10)

ttk.Label(mainframe, text="Payment Type :- ", font=font2).grid(row=8, column=0, padx=10, pady=10)
n = StringVar()
payment=ttk.Combobox(mainframe,  textvariable=n)
payment["values"]=("Weekly","Monthly","Yearly")
payment.grid(row=8, column=1,padx=10, pady=10)
payment.current()

basic = Label(mainframe, text="Basic Salary:-", bg="lightblue", font= font2 )
basic.grid(row=8, column=2, padx=10, pady=10)
basictxt = Entry(mainframe,width=20, border=2)
basictxt.grid(row=8, column=3, padx=10, pady=10)

length = Label(mainframe, text="Length of Service:-", bg="lightblue", font= font2 )
length.grid(row=9, column=0, padx=10, pady=10)
lengthtxt = Entry(mainframe,width=20, border=2)
lengthtxt.grid(row=9, column=1, padx=10, pady=10)
total = Label(mainframe, text="Total: " ,font=font1, bg="lightblue")
total.grid(row=9, column=2, padx=10,pady=10)
totaltxt = Entry(mainframe,width=20, border=2)
totaltxt.grid(row=9, column=3,padx=10, pady=10)
ipad = Label(mainframe, text="Interest Paid: " ,font=font1, bg="lightblue")
ipad.grid(row=10, column=0, padx=10,pady=10)
ipadtxt = Entry(mainframe,width=20, border=2)
ipadtxt.grid(row=10, column=1,padx=10, pady=10)
def calculate():
    num1 = lamounttxt.get()
    num2 = numonthtxt.get()
    num3 = basictxt.get()
    num4 = interesttxt.get()
    num5 = lengthtxt.get()

    ramount = 0.75*int(num1)
    pfee = 0.0025*int(ramount)
    commi = 0.02*int(ramount)
    insur = 0.02*int(ramount)
    tupfront = int(pfee)+int(commi)+int(insur)
    fup = int(ramount)*19*1
    final = int(fup/100)
    totall = int(ramount+final)

    totaltxt.insert(0,str(totall))
    ipadtxt.insert(0,str(tupfront))

def savee():
    try:
        connection = mysql.connector.connect(
        host = "localhost",
        database= "accessloan",
        user = "root",
        password= "")
        my_cursor = connection.cursor()
        my_cursor.execute("INSERT INTO staff VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(
        custnotxt.get(),
        fnametxt.get(),
        marital.get(),
        countrytxt.get(),
        lgeatxt.get(),
        phonetxt.get(),
        accttxt.get(),
        lamounttxt.get(),
        numonthtxt.get(),
        basictxt.get(),
        gende.get(),
        dobtxt.get(),
        state.get(),
        addrtxt.get(),
        kintxt.get(),
        acctnumtxt.get(),
        interesttxt.get(),
        payment.get(),
        lengthtxt.get(),
        totaltxt.get(),
        ipadtxt.get(),
        ))
        connection.commit()
        messagebox.showinfo("Hello","Data inserted successfully")
        connection.close()
    except mysql.connector.Error as e:
        messagebox.showinfo("Hello","Data not successfully")


def reset():
        custnotxt.delete(0,END)
        fnametxt.delete(0,END)
        marital.delete(0,END)
        countrytxt.delete(0,END)
        lgeatxt.delete(0,END)
        phonetxt.delete(0,END)
        accttxt.delete(0,END)
        lamounttxt.delete(0,END)
        numonthtxt.delete(0,END)
        basictxt.delete(0,END)
        gende.delete(0,END)
        dobtxt.delete(0,END)
        state.delete(0,END)
        addrtxt.delete(0,END)
        kintxt.delete(0,END)
        acctnumtxt.delete(0,END)
        interesttxt.delete(0,END)
        payment.delete(0,END)
        lengthtxt.delete(0,END)
        totaltxt.delete(0,END)
        ipadtxt.delete(0,END)
btn1 = Button(mainframe,text="Submit", command=savee, width=9,font=font2)
btn1.grid(row=11, columnspan=2,padx=10, pady=10)
btn2 = Button(mainframe,text="Calculate", command=calculate, width=9,font=font2)
btn2.grid(row=11, columnspan=3,padx=10, pady=10)
btn3 = Button(mainframe,text="Reset", command=reset, width=9,font=font2)
btn3.grid(row=11, columnspan=4,padx=10, pady=10)
window.mainloop()
