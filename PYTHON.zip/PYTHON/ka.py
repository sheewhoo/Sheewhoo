from tkinter.simpledialog import*
import mysql.connector
from mysql.connector import Error

from tkinter import messagebox
import tkinter as tk

root=Tk()
from tkinter import ttk
root.title("PATIENT RECORD")
root.geometry("680x450")
root.configure(bg='brown')
head1=Label(root,text="SIR YAHAYA MEMORIAL HOSPITAL",bg='brown',fg='white',font=('Arial',10,'bold'))
head2=Label(root,text="BIRNIN KEBBI, KEBBI STATE", bg='brown',fg='white',font=('Arial',10,'bold'))
head3=Label(root,text="PATIENT DATA CAPTURE SYSTEM", bg='brown',fg='white',font=('Arial',10,'bold'))
head1.grid(column=3,row=0)
head2.grid(column=3,row=1)
head3.grid(column=3,row=2)
ptn_id=Label(root,text="Patient ID",bg='brown',fg='white')
name=Label(root,text="Full name",bg='brown',fg='white')
ward=Label(root,text="ward name",bg='brown',fg='white')
bd_no=Label(root,text="Bed number",bg='brown',fg='white')
adm_date=Label(root,text="Admission Date",bg='brown',fg='white')
chck_date=Label(root,text="Checkup Date",bg='brown',fg='white')
email=Label(root,text="E-mail address",bg='brown',fg='white')
age=Label(root,text="Date of Birth",bg='brown',fg='white')
d_date=Label(root,text="Discharge Date",bg='brown',fg='white')
phone=Label(root,text="Phone number",bg='brown',fg='white')
occp=Label(root,text="Occupation",bg='brown',fg='white')

ptn_id.grid(column=0,row=3)
name.grid(column=0,row=4)
ward.grid(column=0,row=5)
bd_no.grid(column=0,row=6)
adm_date.grid(column=0,row=10)
chck_date.grid(column=0,row=11)
email.grid(column=5,row=3)
age.grid(column=5,row=4)
d_date.grid(column=5,row=6)
phone.grid(column=5,row=8)
occp.grid(column=5,row=11)

ptn_idTxt=Entry(root,width=10)
ptn_idTxt.grid(column=1,row=3)
nameTxt=Entry(root,width=10)
nameTxt.grid(column=1,row=4)
wardTxt=Entry(root,width=10)
wardTxt.grid(column=1,row=5)
bd_noTxt=Entry(root,width=10)
bd_noTxt.grid(column=1,row=6)
adm_dateTxt=Entry(root,width=10)
adm_dateTxt.grid(column=1,row=10)
chck_dateTxt=Entry(root,width=10)
chck_dateTxt.grid(column=1,row=11)
emailTxt=Entry(root,width=10)
emailTxt.grid(column=6,row=3)
ageTxt=Entry(root,width=10)
ageTxt.grid(column=6,row=4)
d_dateTxt=Entry(root,width=10)
d_dateTxt.grid(column=6,row=6)
phoneTxt=Entry(root,width=10)
phoneTxt.grid(column=6,row=8)
occpTxt=Entry(root,width=10)
occpTxt.grid(column=6,row=11)

ttk.Label(root,text="Marital status").grid(column=0,row=7,padx=6,pady=10)
n=StringVar()
maritalStatus=ttk.Combobox(root,width=7,textvariable=n)
maritalStatus["values"]=("Maried", "Single", "Widowed", "Divorce")
maritalStatus.grid(column=1,row=7)
maritalStatus.current()

ttk.Label(root,text="State of origin ").grid(column=0,row=8,padx=6,pady=10)
n=StringVar()
stateoforigin=ttk.Combobox(root,width=7,textvariable=n)
stateoforigin["values"]=("Kebbi", "Sokoto", "Zamfara", "Kano")
stateoforigin.grid(column=1,row=8)
stateoforigin.current()
ttk.Label(root,text="Local govt ").grid(column=0,row=9,padx=6,pady=15)
n=StringVar()
Localgovt=ttk.Combobox(root,width=7,textvariable=n)
Localgovt["values"]=("Kalgo", "Sakaba", "Argungu", "Augie")
Localgovt.grid(column=1,row=9)
Localgovt.current()
ttk.Label(root,text="Nationality ").grid(column=5,row=5,padx=6,pady=15)
n=StringVar()
nationality=ttk.Combobox(root,width=7,textvariable=n)
nationality["values"]=("Nigerian", "Ghanian", "Amarican", "Liberian")
nationality.grid(column=6,row=5)
nationality.current()
ttk.Label(root,text="Family history ").grid(column=5,row=7,padx=6,pady=15)
n=StringVar()
familyhistory=ttk.Combobox(root,width=7,textvariable=n)
familyhistory["values"]=("Athma", "Alagistic", "Diabitis", "Albinism")
familyhistory.grid(column=6,row=7)
familyhistory.current()
ttk.Label(root,text="Druggs history").grid(column=5,row=9,padx=6,pady=15)
n=StringVar()
druggshistory=ttk.Combobox(root,width=7,textvariable=n)
druggshistory["values"]=("Daily", "Weeekly ", " Monthly", " Yearly")
druggshistory.grid(column=6,row=9)
druggshistory.current()
ttk.Label(root,text="Patient type").grid(column=5,row=10,padx=6,pady=15)
n=StringVar()
patienttype=ttk.Combobox(root,width=7,textvariable=n)
patienttype["values"]=("Adult", "Under-Age", "", "")
patienttype.grid(column=6,row=10)
patienttype.current()

def clr():
     ptn_idTxt.delete(0,END)
     nameTxt.delete(0,END)
     wardTxt.delete(0,END)
     bd_noTxt.delete(0,END)
     adm_dateTxt.delete(0,END)
     chck_dateTxt.delete(0,END)
     ageTxt.delete(0,END)
     d_dateTxt.delete(0,END)
     phoneTxt.delete(0,END)
     occpTxt.delete(0,END)

def clo():
    root.destroy()
def sav():
     try:
          Connection=mysql.connector.connect(
          host='localhost',
          database='patientrecord',
          user='root',
          password="",
          port='3306')
          my_cursor=connection.cursor()
          my_cursor.execute("INSERT INTO patient VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,)",(
          ptn_idTxt.get(),
          nameTxt.get(),
          wardTxt.get(),
          bd_noTxt.get(),
          adm_dateTxt.get(),
          chck_dateTxt.get(),
          ageTxt.get(),
          d_dateTxt.get(),
          phoneTxt.get(),
          occpTxt.get(),
          maritalstatus.get(),
          stateoforigin.get(),
          localgovt.get(),
          nationality.get(),
          familyhistory.get(),
          druggshistory.get(),
          patienttype.get(),
          ))
          connection.commit()
          messagebox.showinfo("Hello","Data Successfully Inserted Into Database")
          connection.close()
     except mysql.connector.error as e:
          messagebox.showinfo("Hello","Error While Inserting Data Into Database")

def delete():
    try:
         connection=mysql.connector.connect(
         host='localhost',
         database='patient',
         user='root',
         password="",
         port='3306')
         my_cursor=connection.cursor()
         my_cursor.execute("DELETE FROM patient where ptn_id="+ptn_idTxt.get())
         messagebox.showinfo("MESSAGE","Data Deleted Successfully")
         connection.commit()
         connection.close()
    except mysql.connector.Error as e:
         messagebox.showinfo("Hello","Failed to delete record from table",e)
def view():
     ptn_id=ptn_id.get()
     connection=mysql.connector.connect(
     host='localhost',
     database='patient',
     user='root',
     password="",
     port='3306')
     my_cursor=connection.cursor()
     my_cursor.execute("Select * from patient where ptn_id="+ptn_id.get())
     results=my_cursor.fetchall()
     count=my_cursor.rowcount
     if count>0:
          for row in result:
              ptn_id.get(row[0])
              nameTxt.get(name)
              wardTxt.insert(0,str(ward))
              bd_noTxt.insert(0,str(bd_no))
              adm_dateTxt.insert(0,str(adm_date))
              chck_dateTxt.insert(0,str(chck_date))
              ageTxt.insert(0,str(age))
              d_dateTxt.insrt(0,str(d_date))
              phone.insert(0,phone)
              occpTxt.insert(0,str(occp))
              maritalstatus.insert(0,maritalstatus)
              stateoforigin.insert(0,stateoforigin)
              localgovt.insert(0,localgovt)
              nationality.insert(0,nationality)
              familyhistory.insert(0,familyhistory)
              druggshistory.insert(0,druggshistory)
              patienttype.insert(0,patienttype)
          else:
               messagebox.showinfo("Hello","recoord not found")
               conn.close()

btn=Button(root,text="Close",width=7,command=clo,bg="green",fg="white")
btn.grid(column=3,row=4)
btn=Button(root,text="Reset",width=7,command=clr,bg="green",fg="white")
btn.grid(column=3,row=5)
btn=Button(root,text="Save",width=7,command=sav,bg="green",fg="white")
btn.grid(column=2,row=12)
btn=Button(root,text="Delete",width=7,command=delete,bg="green",fg="white")
btn.grid(column=3,row=12)
btn=Button(root,text="View",width=7,command=view,bg="green",fg="white")
btn.grid(column=4,row=12)







