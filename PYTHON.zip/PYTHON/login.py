# Write your code here :-)
# Write your code here :-)
import math
from tkinter import*
from tkinter import messagebox
root = Tk()
root.geometry("500x250")
root.resizable(width="false",height="false")
root.title("Login Page")
root.configure(bg="white")

frame = Frame(root, bg="white")
frame.pack()
a = Label(frame, text="ADMIN", font="arial, 20",bg="white").grid(row=0, columnspan=2, padx=1,pady=10)
b = Label(frame, text="Username: ", font="arial, 14",bg="white").grid(row=1, column=0, padx=2,pady=2)
btxt = Entry(frame, width=30)
btxt.grid(row=1, column=1, padx=1,pady=2)
c = Label(frame, text="Password: ", font="arial, 14",bg="white").grid(row=2, column=0, padx=10,pady=20)
ctxt = Entry(frame, show="*", width=30)
ctxt.grid(row=2, column=1, padx=1,pady=2)

def save():
    name = btxt.get()
    pas = ctxt.get()
    if name== "" or pas == "":
        messagebox.showerror("Error","Provide the correct detail............")

    elif name =="Shehu" and pas =="123":
        messagebox.showinfo("Info","logged in the successfully............")
        root.destroy()

        import panel

    elif name =="123" and pas =="123":
        messagebox.showinfo("Info","logged in the successfully............")
        root.destroy()
        import samosa

    else:
        messagebox.showwarning("Warning","Invalid Login Details...........")
def Reset():
    btxt.delete(0,END)
    ctxt.delete(0,END)



btn = Button(frame,text="Login", font="arial,16",command=save, width=20).grid(row=3, column=0, padx=10,pady=20)
btn1 = Button(frame,text="Reset ", font="arial,16",command=Reset, width=20).grid(row=3, column=1, padx=10,pady=20)

root.mainloop()

