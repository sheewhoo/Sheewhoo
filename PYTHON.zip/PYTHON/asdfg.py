# Write your code here :-)
import mysql.connector
from mysql.connector import Error
from tkinter import messagebox
from tkinter import *
window = Tk()
window.geometry("500x600")
window.configure(bg="LIGHTgrey")

window.title("NPC")
def save():
    nam = name.get()
    fnam =fname.get()

    if nam =="1111" or fnam =="1111":


        messagebox.showinfo("Hello","Data inserted successfully")

    else:

        messagebox.showinfo("Hello","Data not successfully")




name = Entry(window,width=20)
name.pack()
fname = Entry(window,width=20)
fname.pack()
btn =  Button(window,text="Submit", command=save, width=20)
btn.place(x=60, y=50)
window.mainloop()
