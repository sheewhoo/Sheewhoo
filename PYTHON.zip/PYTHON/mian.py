# Write your code here :-)
from tkinter import*
import math
window=Tk()
window.geometry("550x300")
window.title("Furniture Cost")
window.configure(bg="grey")

label1 = Label(window,text="Part Cost")
label1.grid(row=0,column=0, padx=2,pady=2)

label1txt = Entry(window, width=20)
label1txt.grid(row=0, column=1, padx=2, pady=2)

label2 = Label(window,text="Engine Cost")
label2.grid(row=0,column=2, padx=2,pady=2)

label2txt = Entry(window, width=20)
label2txt.grid(row=0, column=3, padx=2, pady=2)

label3 = Label(window,text="Petrol Cost")
label3.grid(row=0,column=4, padx=2,pady=2)
label3txt = Entry(window, width=20)
label3txt.grid(row=0, column=5, padx=2, pady=2)

label4 = Label(window,text="Hours worked")
label4.grid(row=1,column=0, padx=2,pady=2)
label4txt = Entry(window, width=20)
label4txt.grid(row=1, column=1, padx=2, pady=2)

label5 = Label(window,text="Charges Hours")
label5.grid(row=1,column=2, padx=2,pady=2)
label5txt = Entry(window, width=20)
label5txt.grid(row=1, column=3, padx=2, pady=2)

label6 = Label(window,text="Total Bill")
label6.grid(row=1,column=4, padx=2,pady=2)
label6txt = Entry(window, width=20)
label6txt.grid(row=1, column=5, padx=2, pady=2)



def sav():
    num1 = label1txt.get()
    num2 = label2txt.get()
    num3 = label3txt.get()
    num4 = label4txt.get()
    num5 = label5txt.get()

    material = float(num1)+float(num2)+float(num3)
    old_bill = float(num4)*float(num5)
    discount = 0.01*float(old_bill)
    total = material+old_bill-discount

    label6txt.insert(0,str(total))

def clo():
    label1txt.delete(0,END)
    label2txt.delete(0,END)
    label3txt.delete(0,END)
    label4txt.delete(0,END)
    label5txt.delete(0,END)
    label6txt.delete(0,END)
btn = Button(window, text="Calculate", command= sav, width=20, bg="grey", font="arial, 14")
btn.grid(row=2, column=2, padx=2, pady=2)
btn1 = Button(window, text="Reset", command=  clo, width=20, bg="grey", font="arial, 14")
btn1.grid(row=2, column=3, padx=2, pady=2)
window.mainloop
