# Write your code here :-)
from tkinter import *

window = Tk()
window.geometry("700x400")
window.title("SCHOOL MANAGEMENT SYSTEM")
frame = Label(window, text="AMBACY INTERNATIONAL SCHOOL", bg="red", font="arial, 16", fg="white", height=2).pack(side=TOP, fill="x",padx=2, pady=2)
frame2 = Label(window, text="SCHOOL MANAGEMENT SYSTEM", bg="grey", font="arial, 16", fg="white", height=2).pack(side=TOP, fill="x", padx=2, pady=2)
frame3 = Frame(window, bg="grey", width=300).pack(side=LEFT, fill="y", padx=2, pady=2)
window.mainloop()
