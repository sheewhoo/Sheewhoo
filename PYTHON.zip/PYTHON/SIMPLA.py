x = 5
if (x>=1):
    print("you are very stupid")
elif(x<=2):
   print("you are doll")
else:
    print("ok")
