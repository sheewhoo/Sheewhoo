# Write your code here :-)
import math
from tkinter import*
from tkinter import messagebox
root = Tk()
root.title("3 Values Calculator")
root.geometry("350x130")
label1 = Label(root, text="First No")
label2 = Label(root, text="Second No")
label3 = Label(root, text="Third No")
label4 = Label(root, text="Product")
label5 = Label(root, text="Sum")
label6 = Label(root, text="Average")
label7 = Label(root, text=" ")
atxt = Entry(root, width=7)
btxt = Entry(root, width=7)
ctxt = Entry(root, width=7)
prodtxt = Entry(root, width=7)
sumtxt = Entry(root, width=7)
avetxt = Entry(root, width=7)

label1.grid(row= 0, column= 0)
label2.grid(row= 0, column= 2)
label3.grid(row= 0, column= 6)
label4.grid(row= 1, column= 0)
label5.grid(row= 1, column= 2)
label6.grid(row= 1, column= 6)
label7.grid(row= 2, column=0 )


atxt.grid(row= 0, column= 1)
btxt.grid(row= 0, column= 3)
ctxt.grid(row= 0, column= 7)
prodtxt.grid(row= 1, column= 1)
sumtxt.grid(row= 1, column= 3)
avetxt.grid(row= 1, column= 7)


def sub():
    num1 = atxt.get()
    num2 = btxt.get()
    num3 = ctxt.get()

    product = float(num1)*float(num2)*float(num3)
    sums = float(num1)+float(num2)+float(num3)
    avgr = float(sums/3)
    prodtxt.insert(0, str(product))
    sumtxt.insert(0,str(sums))
    avetxt.insert(0,str(avgr))

def clr():
        atxt.delete(0,END)
        btxt.delete(0,END)
        ctxt.delete(0,END)
        prodtxt.delete(0,END)
        sumtxt.delete(0,END)
        avetxt.delete(0,END)

btn = Button(root, text="Total", command=sub)
btn.grid(row=3, column=0)

btn1 = Button(root, text="Reset",  command=clr)
btn1.grid(row=3, column=2)

root.mainloop()
